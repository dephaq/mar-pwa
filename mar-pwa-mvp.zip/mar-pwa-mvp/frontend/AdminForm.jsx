import React, { useState } from 'react';

/**
 * AdminForm
 *
 * A simple uncontrolled form for creating a new study.  It collects basic
 * metadata (title, link, duration, reward, deadline) and JSON fields for
 * targeting and quotas.  On submit it makes a POST request to your backend
 * endpoint `/api/studies`.  This component does not include any styling.
 */
export default function AdminForm() {
  const [values, setValues] = useState({
    title: '',
    link: '',
    duration: '',
    reward: '',
    deadline: '',
    targeting: '{}',
    quotas: '{}',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValues((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Prepare payload; parse JSON fields
    const payload = {
      title: values.title,
      link: values.link,
      duration_min: values.duration ? Number(values.duration) : null,
      reward_cents: values.reward ? Math.round(Number(values.reward) * 100) : null,
      deadline_at: values.deadline || null,
      targeting: values.targeting ? JSON.parse(values.targeting) : {},
      quotas: values.quotas ? JSON.parse(values.quotas) : {},
    };
    try {
      const res = await fetch('/api/studies', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        throw new Error('Failed to create study');
      }
      // Reset form or show success toast
      setValues({
        title: '',
        link: '',
        duration: '',
        reward: '',
        deadline: '',
        targeting: '{}',
        quotas: '{}',
      });
      alert('Study created successfully');
    } catch (err) {
      console.error(err);
      alert('Error creating study: ' + err.message);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>
          Title
          <input
            name="title"
            type="text"
            value={values.title}
            onChange={handleChange}
            required
          />
        </label>
      </div>
      <div>
        <label>
          Link
          <input
            name="link"
            type="url"
            value={values.link}
            onChange={handleChange}
            required
          />
        </label>
      </div>
      <div>
        <label>
          Duration (minutes)
          <input
            name="duration"
            type="number"
            min="0"
            value={values.duration}
            onChange={handleChange}
          />
        </label>
      </div>
      <div>
        <label>
          Reward (€)
          <input
            name="reward"
            type="number"
            min="0"
            step="0.01"
            value={values.reward}
            onChange={handleChange}
          />
        </label>
      </div>
      <div>
        <label>
          Deadline
          <input
            name="deadline"
            type="datetime-local"
            value={values.deadline}
            onChange={handleChange}
          />
        </label>
      </div>
      <div>
        <label>
          Targeting (JSON)
          <textarea
            name="targeting"
            rows={4}
            value={values.targeting}
            onChange={handleChange}
          />
        </label>
      </div>
      <div>
        <label>
          Quotas (JSON)
          <textarea
            name="quotas"
            rows={4}
            value={values.quotas}
            onChange={handleChange}
          />
        </label>
      </div>
      <button type="submit">Create Study</button>
    </form>
  );
}