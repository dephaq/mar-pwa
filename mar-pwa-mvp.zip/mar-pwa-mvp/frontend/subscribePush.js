/*
 * subscribePush.js
 *
 * This helper demonstrates how to subscribe a client to Web Push notifications
 * using the VAPID public key.  It assumes that your service worker has
 * already been registered.
 *
 * To use this module, import `subscribeToPush` into your frontend code and
 * call it in response to a user interaction (e.g. a button click).  The
 * function requests notification permission, subscribes to the push manager
 * and then POSTs the subscription object to your backend at
 * `/api/subscriptions`.
 */

export async function subscribeToPush() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
    throw new Error('Web Push is not supported in this browser');
  }
  // Replace with your actual VAPID public key.  The key should be
  // URL-safe base64 encoded.  If you inject the key at build time via
  // environment variables, you can import it from somewhere else.
  const VAPID_PUBLIC_KEY = import.meta.env.VITE_VAPID_PUBLIC_KEY ||
    process.env.VAPID_PUBLIC_KEY;

  // Convert the base64 public key to a UInt8Array
  function urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  // Request notification permission from the user
  const permission = await Notification.requestPermission();
  if (permission !== 'granted') {
    throw new Error('Notification permission denied');
  }

  const registration = await navigator.serviceWorker.ready;
  const subscription = await registration.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
  });

  // POST the subscription to your backend
  await fetch('/api/subscriptions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(subscription),
  });
  return subscription;
}