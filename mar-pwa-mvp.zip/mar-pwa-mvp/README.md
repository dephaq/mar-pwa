MAR PWA MVP Code
=================

This directory contains a minimal proof‑of‑concept implementation of the core pieces
described in the MAR PWA product plan. It is intended as a starting point for
developing the backend and frontend pieces of the MVP.  The code here is **not** a
complete application and will require integration into your existing codebase.

The following pieces are provided:

* **`backend/`** – a simple Express server that supports storing Web Push
  subscriptions and sending notifications via VAPID.  Environment variables
  control the VAPID keys and database connection.
* **`migrations.sql`** – SQL statements to create the minimal tables required for
  push subscriptions, studies, invitations and participations.
* **`frontend/subscribePush.js`** – a small helper that demonstrates how to
  register a service worker and subscribe to Web Push from the client.
* **`frontend/AdminForm.jsx`** – a skeleton React component for the "New
  Study" form used by the admin interface.
* **`.github/workflows/ci.yml`** – an example GitHub Actions workflow that
  installs dependencies, runs linting, builds the frontend and deploys both
  frontend and backend.  You can adjust the deploy steps according to your
  hosting provider (e.g. GitHub Pages, Vercel or Render).

To get started locally, install dependencies in the backend and run `npm start`:

```sh
cd mar-pwa-mvp/backend
npm install
npm start
```

This will start the server on port 3000.  Before starting the server you
need to generate VAPID keys (see [web-push documentation](https://github.com/web-push-libs/web-push))
and set the following environment variables in a `.env` file:

```env
VAPID_PUBLIC_KEY=<your base64 encoded public key>
VAPID_PRIVATE_KEY=<your base64 encoded private key>
VAPID_SUBJECT=mailto:example@example.com
DATABASE_URL=postgresql://user:pass@host:port/dbname
```

The SQL in `migrations.sql` should be run against your PostgreSQL database
before starting the server.  The backend uses `pg` to connect to the
database; you can replace this with Prisma or another ORM if desired.