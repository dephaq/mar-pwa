-- SQL migrations for MAR PWA MVP
--
-- Run this script against your PostgreSQL database to create the minimal
-- tables required for storing Web Push subscriptions, studies, invitations
-- and participations.  Additional tables (Profile, Consent, Reward, etc.)
-- should be added as you implement further features.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Table: device_subscriptions
-- Stores the Web Push subscription details for each device.  The
-- combination of endpoint, p256dh and auth uniquely identifies a device.
CREATE TABLE IF NOT EXISTS device_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  endpoint TEXT NOT NULL UNIQUE,
  p256dh TEXT NOT NULL,
  auth TEXT NOT NULL,
  ua TEXT,
  platform TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked_at TIMESTAMPTZ
);

-- Table: studies
-- Each study represents a survey or marketing research activity.
CREATE TABLE IF NOT EXISTS studies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  link TEXT NOT NULL,
  duration_min INTEGER,
  reward_cents INTEGER,
  deadline_at TIMESTAMPTZ,
  targeting JSONB DEFAULT '{}'::jsonb,
  quotas JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Table: invitations
-- Links users to studies and tracks the status of each invitation.
CREATE TABLE IF NOT EXISTS invitations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  study_id UUID NOT NULL REFERENCES studies(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'pending',
  sent_at TIMESTAMPTZ,
  opened_at TIMESTAMPTZ,
  started_at TIMESTAMPTZ,
  finished_at TIMESTAMPTZ
);

-- Table: participations
-- Records the outcome of a user’s participation in a study.
CREATE TABLE IF NOT EXISTS participations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  study_id UUID NOT NULL REFERENCES studies(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  result TEXT,
  reward_cents INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);