// Simple Express backend for MAR PWA
//
// This server exposes two minimal endpoints:
//  - POST /api/subscriptions: save a Web Push subscription payload to Postgres.
//  - POST /api/notify: send a push notification to a list of subscriptions
//    filtered by a simple segment.  The notification content (title, body,
//    url) is provided by the client.  See migrations.sql for the database
//    schema.

import express from 'express';
import bodyParser from 'body-parser';
import webpush from 'web-push';
import pkg from 'pg';
import dotenv from 'dotenv';

// Load environment variables from .env file when running locally
dotenv.config();

const { Pool } = pkg;
const app = express();
const port = process.env.PORT || 3000;

// Configure VAPID keys for webpush
const {
  VAPID_PUBLIC_KEY,
  VAPID_PRIVATE_KEY,
  VAPID_SUBJECT,
  DATABASE_URL,
} = process.env;

if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY || !VAPID_SUBJECT) {
  console.error('Missing VAPID configuration. Set VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY and VAPID_SUBJECT in your environment.');
  process.exit(1);
}
webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);

// Set up Postgres connection pool
const pool = new Pool({ connectionString: DATABASE_URL });

// Middleware
app.use(bodyParser.json());

// Helper to store subscription into database
async function storeSubscription(payload, userId = null) {
  const { endpoint, keys } = payload;
  const { p256dh, auth } = keys;
  const client = await pool.connect();
  try {
    await client.query(
      `INSERT INTO device_subscriptions (endpoint, p256dh, auth, user_id)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (endpoint) DO NOTHING`,
      [endpoint, p256dh, auth, userId]
    );
  } finally {
    client.release();
  }
}

// POST /api/subscriptions – save a subscription object
app.post('/api/subscriptions', async (req, res) => {
  const subscription = req.body;
  if (!subscription || !subscription.endpoint) {
    return res.status(400).json({ error: 'Invalid subscription payload' });
  }
  try {
    // TODO: associate authenticated user ID if available
    await storeSubscription(subscription, null);
    return res.status(201).json({ ok: true });
  } catch (err) {
    console.error('Error saving subscription', err);
    return res.status(500).json({ error: 'Failed to save subscription' });
  }
});

// POST /api/notify – send push notifications to subscribers
// The request body should contain a JSON object with keys:
// { segment: <optional string>, title: <string>, body: <string>, url: <string> }
app.post('/api/notify', async (req, res) => {
  const { segment, title, body, url } = req.body;
  // Build payload for clients
  const payload = JSON.stringify({ title: title || 'MAR', body, url });
  // Select subscriptions.  If a segment is provided, you can filter here.
  let query = 'SELECT endpoint, p256dh, auth FROM device_subscriptions';
  const params = [];
  if (segment) {
    // For a real application, filter by segment stored on the subscription or user profile
    // Placeholder: no filtering implemented
  }
  try {
    const { rows } = await pool.query(query, params);
    const results = await Promise.all(
      rows.map(({ endpoint, p256dh, auth }) => {
        const sub = {
          endpoint,
          keys: { p256dh, auth },
        };
        return webpush
          .sendNotification(sub, payload)
          .catch((err) => {
            // Ignore failed notifications and log the error
            console.warn('Failed to send notification to', endpoint, err.body || err);
          });
      })
    );
    return res.json({ sent: rows.length });
  } catch (err) {
    console.error('Error sending notifications', err);
    return res.status(500).json({ error: 'Failed to send notifications' });
  }
});

// Health endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Start the server
app.listen(port, () => {
  console.log(`MAR PWA backend listening on port ${port}`);
});